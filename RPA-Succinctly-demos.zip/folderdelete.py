import os
import shutil

origin = os.path.dirname(os.path.abspath(__file__))
shutil.rmtree(origin + '\\Copied', ignore_errors=False, onerror=None)