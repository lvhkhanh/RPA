import os

def mergepaths(path1, path2):
	pieces = []
	parts1, tail1 = os.path.splitdrive(path1)
	parts2, tail2 = os.path.splitdrive(path2)
	result = path2
	parts1 = tail1.split('\\') if '\\' in tail1 else tail1.split('/')
	parts2 = tail2.split('\\') if '\\' in tail2 else tail2.split('/')
	for pitem in parts1:
		if pitem != '':	
			if not pitem in parts2:
				pieces.append(pitem)
	for piece in pieces:
		result = os.path.join(result, piece)
	return result

print(mergepaths("C:\\Projects\\Test", "C:\\Temp\\RPASuccinctly"))