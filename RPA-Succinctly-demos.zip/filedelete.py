import os
import shutil

def filedelete(fname, fld):
    fn = os.path.join(fld, fname)
    try:
        os.unlink(fn)
    except BaseException as err:
        print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
    finally:  
        print('Deleted file: ' + fname + ' in ' + fld)

def getallfilesfld(path):
    files = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        for file in f:
            if not '.db' in file:
                files.append(os.path.join(r, file))
    return files

def deleteall(origin):
    files = getallfilesfld(origin)
    for f in files:
        if os.path.isfile(f):
            o = os.path.dirname(os.path.abspath(f))
            filedelete(os.path.basename(f), o)

origin = os.path.dirname(os.path.abspath(__file__))
deleteall(origin + '\\Copied')