import os
import sys

import PyPDF2
from collections import OrderedDict

def readfields(obj, t=None, res=None, fo=None):
    fa = {'/FT': 'Field Type', 
    '/Parent': 'Parent', 
    '/T': 'Field Name', 
    '/TU': 'Alternate Field Name',
    '/TM': 'Mapping Name', 
    '/Ff': 'Field Flags', 
    '/V': 'Value', 
    '/DV': 'Default Value'}

    if res is None:
        res = OrderedDict()
        items = obj.trailer["/Root"]
        if "/AcroForm" in items:
            t = items["/AcroForm"]
        else:
            return None
    if t is None:
        return res
    obj._checkKids(t, res, fo)
    for attr in fa:
        if attr in t:
            obj._buildField(t, res, fo, fa)
            break
    if "/Fields" in t:
        flds = t["/Fields"]
        for f in flds:
            fld = f.getObject()
            obj._buildField(fld, res, fo, fa)
    return res

def getfields(infile):
    infile = PyPDF2.PdfFileReader(open(infile, 'rb'))
    fields = readfields(infile)
    return OrderedDict((k, v.get('/V', '')) for k, v in fields.items())

def rselects(fn):
    lst = []
    with open(fn, 'r') as fh:  
        for l in fh:
            lst.append(l.rstrip(os.linesep))
    return lst

def bscript(si, items, pdff):
    if pdff:
        of = os.path.splitext(pdff)[0] + '.txt'
        lns = []
        for k, v in items.items():
            if (k in si):
                sselectitm(lns, k, v)
                print('Selectable: ' + k + ' -> ' + v)
            else:
                lns.append(
                    "document.getElementById('" + k + "').value = '" + v + "';\n")
                print('Normal: ' + k + ' -> ' + v)
        scriptf = open(of, 'w')
        scriptf.writelines(lns)
        scriptf.close()

def sselectitm(l, k, v):
    l.append('function setItem(s, v) {')
    l.append('for (var i = 0; i < s.options.length; i++) {')
    l.append('if (s.options[i].text == v) {')
    l.append('s.options[i].selected = true;')
    l.append('return;') 
    l.append('}')
    l.append('}')
    l.append('}')
    l.append('setItem(document.getElementById("' + k + '"), "' + v + '");')

def run(args):
    try: 
        si = rselects('selects.ini')
        if len(args) == 2:
            pdf_file_name = args[1]
            items = getfields(pdf_file_name)
            bscript(si, items, pdf_file_name)
        else:
            files = [f for f in os.listdir('.') 
            if os.path.isfile(f) and f.endswith('.pdf')]
            for f in files:
                items = getfields(f)
                bscript(si, items, f)
    except BaseException as msg:
        print('An error occured... :( ' + str(msg))

if __name__ == '__main__':
    run(sys.argv)