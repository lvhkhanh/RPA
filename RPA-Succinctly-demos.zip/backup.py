import os
import shutil
import zipfile
import time

from readcfg import readcfg

def mergepaths(path1, path2):
	pieces = []
	parts1, tail1 = os.path.splitdrive(path1)
	parts2, tail2 = os.path.splitdrive(path2)
	result = path2
	parts1 = tail1.split('\\') if '\\' in tail1 else tail1.split('/')
	parts2 = tail2.split('\\') if '\\' in tail2 else tail2.split('/')
	for pitem in parts1:
		if pitem != '':	
			if not pitem in parts2:
				pieces.append(pitem)
	for piece in pieces:
		result = os.path.join(result, piece)
	return result

def startzip(dest, opt):
	zipf = None
	if opt == 'z':
		dir = os.path.dirname(dest)
		if not os.path.exists(dir):
			os.makedirs(dir)
		zipf = zipfile.ZipFile(addtofilename(dest), 'w', allowZip64=True)
	return zipf

def endzip(zipf, opt):
    if not zipf is None and opt == 'z':
        zipf.close()

def isexcluded(fname, excl):
    res = False
    lexc = excl.split(',')
    if len(lexc) > 0:
        if os.path.splitext(fname)[1] in lexc:
            res = True
    return res

def fileaction(op):
    try:
        zipf = startzip(op['dest'], op['type'])
        cmdfolder(zipf, op['origin'], op['dest'], op['type'], op['exclude'])
        if op['type'] == 'd':
            shutil.rmtree(op['origin'])
    except BaseException as err:
        print('ERROR: ' + str(err))
    finally:
        endzip(zipf, op['type'])

def cmdfolder(zipf, origin, dest, opt, exc):
	for fld, sflds, fnames in os.walk(origin):
		cmdfoldercore(zipf, fld, dest, opt, sflds, fnames, exc)

def cmdfoldercore(zipf, fld, dest, opt, sflds, fnames, exc):
	print('Processing folder: ' + fld)
	cmdsubfolder(fld, opt, sflds)
	cmdfiles(zipf, fld, dest, opt, fnames, exc)

def cmdsubfolder(fld, opt, sflds):
	for sf in sflds:
		print('Processing subfolder: ' + sf + ' in ' + fld)

def cmdfiles(zipf, fld, dest, opt, fnames, exc):
	for fname in fnames:
		if not isexcluded(fname, exc):
			if opt == 'c':
				filecopy(fname, fld, dest)
			elif opt == 'm':
				filemove(fname, fld, dest)
			elif opt == 'd':
				filedelete(fname, fld, dest)
			elif opt == 'z':
				filezip(zipf, fname, fld)

def filecopy(fname, fld, dest):
	fn = os.path.join(fld, fname)
	d = mergepaths(fld, dest)
	try:
		if not os.path.exists(d):
			os.makedirs(d)
		shutil.copy(fn, d)
	except BaseException as err:
		print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
	finally:
		print('Copied file: ' + fname + ' in ' + fld)

def filemove(fname, fld, dest):
	fn = os.path.join(fld, fname)
	d = mergepaths(fld, dest)
	try:
		if not os.path.exists(d):
			os.makedirs(d)
		shutil.move(fn, d)
	except BaseException as err:
		print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
	finally:
		print('Moved file: ' + fname + ' in ' + fld)

def filedelete(fname, fld, dest):
    fn = os.path.join(fld, fname)
    try:
        os.unlink(fn)
    except BaseException as err:
        print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
    finally:  
        print('Deleted file: ' + fname + ' in ' + fld)

def filezip(zipf, fname, fld):
	fn = os.path.join(fld, fname)
	if fn.lower() != zipf.filename.lower():
		try:
			zipf.write(fn)
		except BaseException as err:
			print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
		finally:  
			print('Zipped file: ' + fname + ' in ' + fld)

def addtofilename(fname):
    datet = str(time.strftime("%Y%m%d-%H%M%S"))
    if '%%' in fname:
        fname = fname.replace('%%', datet)
    return fname

def runall(): 
    cfg = os.path.splitext(os.path.basename('readcfg'))[0] + '.ini'
    items = readcfg(cfg)
    for item in items:
        if bool(item) is True:
            if item['type'] == 'f':
                ftpaction(item)
            else:
                fileaction(item)

#for ftp...
def ftpaction(opts):
    #todo...
	return

runall()