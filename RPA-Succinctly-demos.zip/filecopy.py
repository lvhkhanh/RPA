import os
import shutil

def mergepaths(path1, path2):
	pieces = []
	parts1, tail1 = os.path.splitdrive(path1)
	parts2, tail2 = os.path.splitdrive(path2)
	result = path2
	parts1 = tail1.split('\\') if '\\' in tail1 else tail1.split('/')
	parts2 = tail2.split('\\') if '\\' in tail2 else tail2.split('/')
	for pitem in parts1:
		if pitem != '':	
			if not pitem in parts2:
				pieces.append(pitem)
	for piece in pieces:
		result = os.path.join(result, piece)
	return result

def filecopy(fname, fld, dest):
	fn = os.path.join(fld, fname)
	d = mergepaths(fld, dest)
	try:
		if not os.path.exists(d):
		    os.makedirs(d)
		shutil.copy(fn, d)
	except BaseException as err:
		print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
	finally:
		print('Copied file: ' + fname + ' in ' + fld)

def getallfilesfld(path):
    files = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        for file in f:
            if not '.db' in file:
                files.append(os.path.join(r, file))
    return files

def copyall(origin, dest):
    files = getallfilesfld(origin)
    for f in files:
        if os.path.isfile(f):
            o = os.path.dirname(os.path.abspath(f))
            filecopy(os.path.basename(f), o, dest)

origin = os.path.dirname(os.path.abspath(__file__))
copyall(origin, origin + '\\Copied')