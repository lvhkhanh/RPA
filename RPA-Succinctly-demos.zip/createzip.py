import os
import time
import zipfile

def filezip(zipf, fname, fld):
    fn = os.path.join(fld, fname)
    try:
        zipf.write(fn)
    except BaseException as err:
        print('ERROR: ' + fname + ' in ' + fld + ' with: ' + str(err))
    finally:  
        print('Zipped file: ' + fname + ' in ' + fld)

def getallfilesfld(path):
    files = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        for file in f:
            if not '.db' in file:
                files.append(os.path.join(r, file))
    return files

def addtofilename(fname):
    datet = str(time.strftime("%Y%m%d-%H%M%S"))
    if '%%' in fname:
        fname = fname.replace('%%', datet)
    return fname

def zipall(origin, dest):
    zipf = zipfile.ZipFile(addtofilename(dest), 'w', allowZip64=True)
    files = getallfilesfld(origin)
    for f in files:
        if os.path.isfile(f):
            o = os.path.dirname(os.path.abspath(f))
            filezip(zipf, os.path.basename(f), o)
    if not zipf is None:
        zipf.close()

origin = os.path.dirname(os.path.abspath(__file__))
zipall(origin + '\\Copied', origin + '\\Copied_%%.zip')